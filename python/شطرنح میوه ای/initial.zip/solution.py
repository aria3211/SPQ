def fruits(fruit_list):
